<?php

require_once 'Book.php';

class BookController
{
    function render($view, $data = [])
    {
        $view_file = $view . '.php';

        if (is_file($view_file)) {
            extract($data);
            require_once $view_file;
        } else {
            echo 'Can\'t find view file: ' . $view_file;
        }
    }

    function home()
    {
        $books = Book::getAll();
        $this->render('home', ['books' => $books]);
    }

    function add()
    {
        $this->render('add');
    }

    function insert() {
        $name = $_REQUEST['name'];
        $publisher = $_REQUEST['publisher'];
        $price = $_REQUEST['price'];
        $message = '';
        $result = false;

        if (isset($name) && isset($publisher) && isset($price)) {
            $id = Book::insert(['name' => $name, 'publisher' => $publisher, 'price' => $price]);
            if ($id) {
                $message = 'Add book successful!';
                $result = true;
            }
            else {
                $message = 'Add book failed!';
            }
        }
        else {
            $message = 'Add book failed!';
        }

        $this->render('add', ['name' => $name, 'publisher' => $publisher, 'price' => $price, 'message' => $message, 'result' => $result]);
    }

    function getByName()
    {
        $name = $_REQUEST['name'];
        $books = Book::getByName($name);
        $this->render('home', ['books' => $books, 'name' => $name]);
    }
}