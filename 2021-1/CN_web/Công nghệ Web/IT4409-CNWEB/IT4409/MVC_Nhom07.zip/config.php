<?php

const DB_HOST = 'localhost';
const DB_NAME = 'db_07';
const DB_USERNAME = 'test123';
const DB_PASSWORD = 'test123';
