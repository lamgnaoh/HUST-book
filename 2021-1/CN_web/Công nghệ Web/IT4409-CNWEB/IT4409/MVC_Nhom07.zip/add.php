<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="" href="css/book.css">
    <title>Add new book</title>
</head>
<body>
    <h1>New book</h1>
    <?php 
        if (isset($message)) {
            if ($result) {
                echo '<div class="message" style="color:green; text-align:center">' . $message . '</div><br>';
            }
            else {
                echo '<div class="message" style="color:red; text-align:center">' . $message . '</div><br>';
            }
        }  
    ?>
    <form method="POST" action="index.php" autocomplete="off" class="form-add">
        <div class="input">
            <div class="input-text">Name: </div>
            <input type="text" name="name" <?php if (isset($name)) { echo 'value=' . $name; } ?> required>
        </div>
        <div class="input">
            <div class="input-text"> Publisher:</div>
            <input type="text" name="publisher" <?php if (isset($publisher)) { echo 'value=' . $publisher; } ?> required>
        </div>
        <div class="input">
            <div class="input-text">Price:</div>
            <input type="text" name="price" <?php if (isset($price)) { echo 'value=' . $price; } ?> required>
        </div>
        <input type="hidden" name="action" value="insert">
        <div class="add-footer">
            <button type="submit">Add</button>
            <a href="index.php">
                <button type="button">Home</button>
            </a>
        </div>
    </form>
</body>
</html>