<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/book.css">
    <title>Home Page</title>
</head>
<body>
    <h1>List Book</h1>
    <form id="searchBook" action="index.php" method="post" autocomplete="off">
        <input type="text" name="name" value="<?php if (isset($name)) { echo $name; } ?>" placeholder="find by name">
        <input type="hidden" name="action" value="getByName">
        <button type="submit">Search</button>
    </form>

    <div>
        <a href="add.php">
            <button class="add-book">New book</button>
        </a>
    </div>
    <table>
    <tr>
        <th>ID</th>
        <th>Name</th>
        <th>Publisher</th>
        <th>Price</th>
    </tr>

    <?php
        if ($books) {
            foreach ($books as $book) {
                $row = '<tr>'
                        . '<td>' . $book['id'] . '</td>'
                        . '<td>' . $book['name'] . '</td>'
                        . '<td>' . $book['publisher'] . '</td>'
                        . '<td>' . $book['price'] . '</td>'
                        . '</tr>';
                echo $row;
            }
        }

    ?>

    </table>

</body>
</html>