<?php

require_once 'BookController.php';

$action = isset($_REQUEST['action']) ?$_REQUEST['action'] : null;
$router = ['home', 'add', 'insert', 'getAll', 'getByName'];

if (!in_array($action, $router)) {
    $action = 'home';
}

$controller = new \BookController();
$controller->$action();