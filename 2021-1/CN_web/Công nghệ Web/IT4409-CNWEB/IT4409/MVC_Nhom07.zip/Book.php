<?php

class Book {
    private static $table = 'book';
    private static $instance = null; 

    public static function getInstance() {
        if (!isset(self::$instance)) {
            try {
                self::$instance = new \PDO('mysql:host=' . DB_HOST . ';dbname=' . DB_NAME, DB_USERNAME, DB_PASSWORD);
                self::$instance->exec("SET NAMES 'utf8'");
            } catch (\PDOException $ex) {
                die ($ex->getMessage());
            }
        }
        return self::$instance;
    }

    public static function getAll()
    {
        $list = [];
        $db = self::getInstance();
        $stmt = $db->prepare('SELECT * FROM ' . static::$table);
        $stmt->execute();
        $list = $stmt->fetchAll();
        return $list;
    }

    public static function insert($data = []) {
        $db = self::getInstance();
        try {
            $stmt = $db->prepare('INSERT INTO ' . static::$table . ' (name, publisher, price) 
                              VALUES (:name, :publisher, :price)');

            $stmt->execute(['name' => $data['name'], 'publisher' => $data['publisher'],
                            'price' => $data['price']]);

            return $db->lastInsertId();
        }
        catch (\PDOException $e) {
            return null;
        }
        
    }

    public static function getByName($name) {
        $list = [];
        $db = self::getInstance();
        $stmt = $db->prepare('SELECT * FROM ' . static::$table . ' WHERE name LIKE :name');
        $stmt->execute(['name' => '%'.$name.'%']);
        $list = $stmt->fetchAll();
        return $list;
    }
}