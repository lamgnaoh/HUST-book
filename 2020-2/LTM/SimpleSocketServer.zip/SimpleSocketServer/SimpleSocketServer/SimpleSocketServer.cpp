// SimpleSocketServer.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <WinSock2.h>

int main()
{
	WSADATA DATA;
	WSAStartup(MAKEWORD(2, 2), &DATA);
	SOCKET s = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
	if (s == INVALID_SOCKET)
	{
		return 0;
	}
	SOCKADDR_IN saddr, caddr;
	saddr.sin_family = AF_INET;
	saddr.sin_port = htons(8888);
	saddr.sin_addr.S_un.S_addr = 0;
	bind(s, (sockaddr*)&saddr, sizeof(saddr));
	listen(s, 10);
	int clen = sizeof(caddr);
	SOCKET c = accept(s, (sockaddr*)&caddr, &clen);
	if (c == INVALID_SOCKET)
	{
		return 0;
	}
	char* welcome = "Hello!\n";
	send(c, welcome, strlen(welcome), 0);
	char* buffer = NULL;	
	int len = 0;
	do
	{
		char tmpBuffer[8];
		memset(&tmpBuffer, 0, 8);
		int r = recv(c, tmpBuffer, 7, 0);
		if (r > 0)
		{
			buffer = (char*)realloc(buffer, len + r + 1);
			memset(buffer + len, 0, r + 1);
			memcpy(buffer + len, &tmpBuffer, r);
			len += r;
		}		
		if (r < 7)
		{
			break;
		}
	} while (0 == 0);
	free(buffer);
	buffer = NULL;
	closesocket(c);
	closesocket(s);
	WSACleanup();
    return 0;
}

