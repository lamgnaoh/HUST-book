// Telnet Server.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <WinSock2.h>
int userCount = 0;
char** userName = NULL;
char** userPsw = NULL;
char* userFilePath = "C:\\Temp\\Telnet.Users";
DWORD WINAPI ClientThread(LPVOID arg);

void FreeUserPsw()
{
	for (int i = 0; i < userCount; i++)
	{
		free(userName[i]);
		userName[i] = NULL;
		free(userPsw[i]);
		userPsw[i] = NULL;
	}
	free(userName);
	userName = NULL;
	free(userPsw);
	userPsw = NULL;
}
void LoadUserPsw()
{
	FILE* f = fopen(userFilePath, "rt");
	if (f != NULL)
	{
		char line[1024];
		userCount = 0;
		while (!feof(f))
		{
			memset(line, 0, sizeof(line));
			fgets(line, 1023, f);
			userName = (char**)realloc(userName, (userCount + 1) * sizeof(char*));
			userPsw = (char**)realloc(userPsw, (userCount + 1) * sizeof(char*));
			userName[userCount] = (char*)calloc(1024, 1);
			userPsw[userCount] = (char*)calloc(1024, 1);
			memset(userName[userCount], 0, 1024);
			memset(userPsw[userCount], 0, 1024);
			sscanf(line, "%s%s", userName[userCount], userPsw[userCount]);
			userCount += 1;
		}
		fclose(f);
	}
}

int main()
{
	LoadUserPsw();
	WSADATA DATA;
	WSAStartup(MAKEWORD(2, 2), &DATA);
	SOCKET s = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
	SOCKADDR_IN saddr;
	saddr.sin_family = AF_INET;
	saddr.sin_port = htons(5000);
	saddr.sin_addr.S_un.S_addr = 0;
	bind(s, (sockaddr*)&saddr, sizeof(saddr));
	listen(s, 10);
	while (0 == 0)
	{
		SOCKADDR_IN caddr;
		int clen = sizeof(caddr);
		SOCKET c = accept(s, (sockaddr*)&caddr, &clen);
		DWORD ID = 0;
		CreateThread(NULL, 0, ClientThread, (LPVOID)c, 0, &ID);
	}

	FreeUserPsw();
    return 0;
}

DWORD WINAPI ClientThread(LPVOID arg)
{
	SOCKET c = (SOCKET)arg;
	char* welcome = "Hay dang nhap theo dinh dang <user psw>\n";	
	char buffer[1024];
	int i = 0;
	do
	{
		send(c, welcome, strlen(welcome), 0);
		memset(buffer, 0, sizeof(buffer));
		recv(c, buffer, 1023, 0);
		char uName[1024];
		char uPsw[1024];
		memset(uName, 0, sizeof(uName));
		memset(uPsw, 0, sizeof(uPsw));
		sscanf(buffer, "%s%s", uName, uPsw);		
		for (i = 0; i < userCount; i++)
		{
			if (strcmp(uName, userName[i]) == 0 && strcmp(uPsw, userPsw[i]) == 0)
			{
				break;
			}
		}		
	} while (i == userCount);
	while (0 == 0)
	{
		memset(buffer, 0, sizeof(buffer));
		recv(c, buffer, 1023, 0);		
		while (buffer[strlen(buffer) - 1] == '\r' ||
			buffer[strlen(buffer) - 1] == '\n')
		{
			buffer[strlen(buffer) - 1] = 0;
		}

		char command[1024];
		memset(command, 0, sizeof(command));
		sprintf(command, "%s > c:\\temp\\output.txt", buffer);
		system(command);
		FILE* f = fopen("c:\\temp\\output.txt","rt");
		if (f != NULL)
		{
			while (!feof(f))
			{
				memset(buffer, 0, sizeof(buffer));
				fgets(buffer, 1023, f);
				send(c, buffer, strlen(buffer), 0);
			}
			fclose(f);
		}
	}
	return 0;
}
