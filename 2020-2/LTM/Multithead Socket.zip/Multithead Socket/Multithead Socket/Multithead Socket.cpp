// Multithead Socket.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <WinSock2.h>
#include <Windows.h>
DWORD WINAPI SendRecvThread(LPVOID param);
HANDLE* h = NULL;
SOCKET* client = NULL;
int count = 0;

int main()
{
	WSADATA DATA;
	WSAStartup(MAKEWORD(2, 2), &DATA);
	SOCKET s = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
	SOCKADDR_IN saddr;
	saddr.sin_family = AF_INET;
	saddr.sin_port = htons(8888);
	saddr.sin_addr.S_un.S_addr = 0;
	bind(s, (sockaddr*)&saddr, sizeof(saddr));
	listen(s, 10);
	while (0 == 0)
	{
		SOCKADDR_IN caddr;
		int clen = sizeof(caddr);
		SOCKET c = accept(s, (sockaddr*)&caddr, &clen);
		DWORD ID = 0;
		HANDLE tmp = CreateThread(NULL, 0, SendRecvThread, (LPVOID)c, 0, &ID);
		h = (HANDLE*)realloc(h, (count + 1) * sizeof(HANDLE));
		h[count] = tmp;
		client = (SOCKET*)realloc(client, (count + 1) * sizeof(SOCKET));
		client[count] = c;
		count += 1;
	}
    return 0;
}
DWORD WINAPI SendRecvThread(LPVOID param)
{
	SOCKET c = (SOCKET)param;
	char* welcome = "Xin chao\n";
	send(c, welcome, strlen(welcome), 0);
	while (0 == 0)
	{
		char buffer[1024];
		memset(buffer, 0, sizeof(buffer));
		int r = recv(c, buffer, 1023, 0);
		if (r > 0)
		{
			printf("%s", buffer);
			while (buffer[strlen(buffer) - 1] == '\n' ||
				buffer[strlen(buffer) - 1] == '\r')
			{
				buffer[strlen(buffer) - 1] = 0;
			}
			if (strcmp(buffer, "exit") == 0)
			{
				break;
			}
		}		
	}
	char* bye = "Bye!\n";
	send(c, bye, strlen(bye), 0);
	closesocket(c);
	for (int i = 0; i < count; i++)
	{
		if (client[i] == c)
		{
			CloseHandle(h[i]);
			break;
		}
	}
}

