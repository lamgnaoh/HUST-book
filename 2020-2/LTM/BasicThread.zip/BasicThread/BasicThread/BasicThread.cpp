// BasicThread.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <Windows.h>

DWORD WINAPI MyFunction(LPVOID x)
{
	printf("%d\n", (int)x);
	return 0;
}

int main()
{
	HANDLE h[1000];
	for (int i = 0; i < 1000; i++)
	{
		DWORD ID = 0;
		h[i] = CreateThread(NULL, 0, MyFunction, (LPVOID)i, 0, &ID);
	}
	WaitForMultipleObjects(1000, h, TRUE, INFINITE);
	for (int i = 0; i < 1000; i++)
	{
		CloseHandle(h[i]);
	}
    return 0;
}

