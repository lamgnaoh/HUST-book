// Thread+Select.cpp : Defines the entry point for the console application.
//
#define FD_SETSIZE 1024
#define MAX_CLIENT FD_SETSIZE - 1

#include "stdafx.h"
#include <WinSock2.h>
SOCKET* c = NULL;
int n = 0;

DWORD WINAPI ClientThread(LPVOID arg)
{
	int start = (int)arg - 1;
	printf("New thread handles socket from [%d] to MIN(%d,%d)\n", start, start + MAX_CLIENT - 1, n - 1);
	//Luong nay se xu ly cac socket co index tu [start] den [start + MAX_CLIENT - 1] hoac [n - 1]
	fd_set fdread;
	while (0 == 0)
	{
		FD_ZERO(&fdread);
		for (int i = start; i < start + MAX_CLIENT && i < n; i++)
		{
			FD_SET(c[i], &fdread);
		}
		TIMEVAL t;
		t.tv_sec = 1;
		t.tv_usec = 0;
		select(0, &fdread, NULL, NULL, &t);
		for (int i = start; i < start + MAX_CLIENT && i < n; i++)
		{
			if (FD_ISSET(c[i], &fdread))
			{
				char buffer[1025];
				memset(buffer, 0, sizeof(buffer));
				recv(c[i], buffer, 1024, 0);
				printf("%s\n", buffer);
			}
		}
	}
	return 0;
}

int main()
{
	WSADATA DATA;
	WSAStartup(MAKEWORD(2, 2), &DATA);
	SOCKET s = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
	SOCKADDR_IN saddr;
	saddr.sin_addr.S_un.S_addr = 0;
	saddr.sin_family = AF_INET;
	saddr.sin_port = htons(8888);
	bind(s, (sockaddr*)&saddr, sizeof(saddr));
	listen(s, 10);
	fd_set fdread;
	while (0 == 0)
	{
		FD_ZERO(&fdread);
		FD_SET(s, &fdread);
		for (int i = 0; i < MAX_CLIENT && i < n; i++)
		{
			FD_SET(c[i], &fdread);
		}	

		select(0, &fdread, NULL, NULL, NULL);
		if (FD_ISSET(s, &fdread))
		{
			SOCKADDR_IN caddr;
			int clen = sizeof(caddr);
			SOCKET tmp = accept(s, (sockaddr*)&caddr, &clen);
			c = (SOCKET*)realloc(c, (n + 1) * sizeof(SOCKET));
			c[n] = tmp;
			n += 1;
			//Quyet dinh mo them Thread
			if ((n > 1) && ((n - 1) % MAX_CLIENT  == 0))
			{
				DWORD ID = 0;
				CreateThread(NULL, 0, ClientThread, (LPVOID)n, 0, &ID);
			}
		}

		for (int i = 0; i < MAX_CLIENT && i < n; i++)
		{
			if (FD_ISSET(c[i], &fdread))
			{
				char buffer[1025];
				memset(buffer, 0, sizeof(buffer));
				recv(c[i], buffer, 1024, 0);
				printf("%s\n", buffer);
			}
		}
	}
    return 0;
}

