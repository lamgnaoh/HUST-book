// EventSelect.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <WinSock2.h>

SOCKET sk[1024];
HANDLE e[1024];
int count = 0;

int main()
{
	WSADATA DATA;
	WSAStartup(MAKEWORD(2, 2), &DATA);
	SOCKET s = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
	SOCKADDR_IN saddr;
	saddr.sin_addr.S_un.S_addr = 0;
	saddr.sin_family = AF_INET;
	saddr.sin_port = htons(8888);
	bind(s, (sockaddr*)&saddr, sizeof(saddr));
	listen(s, 10);
	e[count] = WSACreateEvent();
	WSAResetEvent(e[count]);
	WSAEventSelect(s, e[count], FD_ACCEPT);

	count += 1;

	while (0 == 0)
	{
		DWORD index = WSAWaitForMultipleEvents(count, e, FALSE, INFINITE, FALSE);
		index -= WSA_WAIT_EVENT_0;
		DWORD r = WSAWaitForMultipleEvents(1, e, FALSE, 100, FALSE);
		if (r != WSA_WAIT_FAILED & r != WSA_WAIT_TIMEOUT)
		{
			WSAResetEvent(e[0]);
			SOCKADDR_IN caddr;
			int clen = sizeof(caddr);
			SOCKET tmp = accept(s, (sockaddr*)&caddr, &clen);
			e[count] = WSACreateEvent();
			WSAResetEvent(e[count]);
			WSAEventSelect(tmp, e[count], FD_READ | FD_WRITE | FD_CLOSE);
			sk[count] = tmp;
			count += 1;
		}

		for (int i = index; i > 0 && i < count; i++)
		{
			DWORD r = WSAWaitForMultipleEvents(1, &e[i], FALSE, 100, FALSE);
			WSAResetEvent(e[i]);
			if (r != WSA_WAIT_FAILED & r != WSA_WAIT_TIMEOUT)
			{
				WSANETWORKEVENTS ne;
				WSAEnumNetworkEvents(sk[i], e[i], &ne);
				if (ne.lNetworkEvents & FD_READ)
				{
					char buffer[1025];
					memset(buffer, 0, sizeof(buffer));
					recv(sk[i], buffer, 1024, 0);
					printf("%s\n", buffer);
				}
				if (ne.lNetworkEvents & FD_WRITE)
				{
					printf("Data sent\n");
				}
				if (ne.lNetworkEvents & FD_CLOSE)
				{
					printf("A client has disconnected\n");
				}
			}
		}
	}
    return 0;
}

