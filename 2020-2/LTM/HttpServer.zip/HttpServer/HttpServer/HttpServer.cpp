// Telnet Server.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <WinSock2.h>
int userCount = 0;
char** userName = NULL;
char** userPsw = NULL;
char* userFilePath = "C:\\Temp\\Telnet.Users";
DWORD WINAPI ClientThread(LPVOID arg);
char* html = NULL;

int main()
{	
	WSADATA DATA;
	WSAStartup(MAKEWORD(2, 2), &DATA);
	SOCKET s = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
	SOCKADDR_IN saddr;
	saddr.sin_family = AF_INET;
	saddr.sin_port = htons(5000);
	saddr.sin_addr.S_un.S_addr = 0;
	bind(s, (sockaddr*)&saddr, sizeof(saddr));
	listen(s, 10);
	while (0 == 0)
	{
		SOCKADDR_IN caddr;
		int clen = sizeof(caddr);
		SOCKET c = accept(s, (sockaddr*)&caddr, &clen);
		DWORD ID = 0;
		CreateThread(NULL, 0, ClientThread, (LPVOID)c, 0, &ID);
	}
	
	return 0;
}

void AppendHTML(char* str)
{
	char* tmp1 = "\\\\";
	while (strstr(str, tmp1))
	{
		int len = strlen(str);
		char* found = strstr(str, tmp1);
		found[0] = '/';
		strcpy(found + 1, found + 2);
		memset(str + len - 1, 0, 1);
	}	

	char* tmp = (char*)calloc(1024, 1);
	sprintf(tmp, "<a href=\"%s\">%s</a>", str, str);
	int oldLen = html == NULL? 0 : strlen(html);
	int newSize = oldLen + strlen(tmp) + 1;
	html = (char*)realloc(html, newSize);
	memset(html + oldLen, 0, newSize - oldLen);
	strcpy(html + oldLen, tmp);
	free(tmp);
	tmp = NULL;
}

DWORD WINAPI ClientThread(LPVOID arg)
{
	SOCKET c = (SOCKET)arg;
	char buffer[1024];
	char verb[1024];
	char path[1024];
	char http[1024];
	memset(buffer, 0, sizeof(buffer));
	recv(c, buffer, 1023, 0);
	memset(verb, 0, sizeof(verb));
	memset(path, 0, sizeof(path));
	memset(http, 0, sizeof(http));
	sscanf(buffer, "%s%s%s", verb, path, http);
	char* tmp = "%20";
	while (strstr(path, tmp))
	{
		int len = strlen(path);
		char* found = strstr(path, tmp);
		found[0] = ' ';
		strcpy(found + 1, found + 3);			
		memset(path + len - 2, 0, 2);
	}
	while ((strlen(path) > 1) && strstr(path + 1, "/"))
	{
		char* found = strstr(path + 1, "/");
		found[0] = '\\';
	}
	if ((strncmp(path, "/FOLDER_", 8) == 0) || (strcmp(path,"/") == 0))
	{
		if (strncmp(path, "/FOLDER_", 8) == 0)
		{
			strcpy(path, path + 8);
		}
		if (strcmp(path, "/") == 0) //ROOT DIRECTORY
		{
			if (html != NULL)
			{
				free(html);
				html = NULL;
			}
			AppendHTML("<html>");
			WIN32_FIND_DATAA fData;
			HANDLE hFind = FindFirstFileA("c:\\*.*", &fData);
			AppendHTML(fData.cFileName);
			AppendHTML("<br>");
			BOOL next = FALSE;
			do
			{
				next = FindNextFileA(hFind, &fData);
				char* prefix = (char*)calloc(1024, 1);
				if (fData.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)
				{
					sprintf(prefix, "FOLDER_%s", fData.cFileName);
				}
				else
				{
					sprintf(prefix, "FILE_%s", fData.cFileName);
				}
				AppendHTML(prefix);
				AppendHTML("<br>");
				free(prefix);
				prefix = NULL;
			} while (next == TRUE);
			AppendHTML("</html>");
			send(c, html, strlen(html), 0);
			free(html);
			html = NULL;
			closesocket(c);
		}
		else
		{
			if (html != NULL)
			{
				free(html);
				html = NULL;
			}
			AppendHTML("<html>");
			WIN32_FIND_DATAA fData;
			char* fullpath = (char*)calloc(1024, 1);
			sprintf(fullpath, "c:\\%s\\*.*", path);
			HANDLE hFind = FindFirstFileA(fullpath, &fData);
			free(fullpath);
			fullpath = NULL;
			AppendHTML(fData.cFileName);
			AppendHTML("<br>");
			BOOL next = FALSE;
			do
			{
				next = FindNextFileA(hFind, &fData);
				char* tmp = (char*)calloc(1024, 1);
				if (fData.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)
				{
					sprintf(tmp, "FOLDER_%s\\%s", path, fData.cFileName);
				}
				else
					sprintf(tmp, "FILE_%s\\%s", path, fData.cFileName);

				AppendHTML(tmp);
				AppendHTML("<br>");
				free(tmp);
				tmp = NULL;
			} while (next == TRUE);
			AppendHTML("</html>");
			send(c, html, strlen(html), 0);
			free(html);
			html = NULL;
			closesocket(c);
		}
	}
	else
	{
		if (strncmp(path, "/FILE_", 6) == 0)
		{
			if (strncmp(path, "/FILE_", 6) == 0)
			{
				char* header = "HTTP/1.1 200\r\nContent-Type: audio/mp3\r\n\r\n";
				send(c, header, strlen(header), 0);
				strcpy(path, path + 6);
				char* fullpath = (char*)calloc(1024, 1);
				sprintf(fullpath, "c:\\%s", path);
				FILE* f = fopen(fullpath, "rb");
				char* buffer = (char*)calloc(1024, 1);
				while (!feof(f))
				{
					int n = fread(buffer, 1, 1024, f);
					if (n > 0)
					{
						send(c, buffer, n, 0);
					}
				}
				fclose(f);
				free(fullpath);
				fullpath = NULL;				
				closesocket(c);
			}
		}
	}
	return 0;
}
